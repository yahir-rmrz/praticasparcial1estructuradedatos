# hacer un  programa que lea 10 numeros y los almacene en una lista
# make a program that reads 10 numbers and stores them in a list

a = []   # lista vac�a donde se almacenar�n los n�meros / empty list to store the numbers
s = 0    # acumulador para la suma / accumulator for the sum
n = 0    # contador de n�meros ingresados / counter of entered numbers

numeros = "1, 2, 3 ,4 , 5, 6, 7, 8, 9, 0"  
# cadena con caracteres permitidos / string with allowed characters

while(n < 10):   # bucle hasta que se ingresen 10 n�meros / loop until 10 numbers are entered
    b =  input('Escribe un numero \n')  
    # se pide un n�mero en forma de texto / ask for a number as text
    x = 0   # contador de d�gitos v�lidos / counter of valid digits
    
    for i in b:   # recorrer cada car�cter ingresado / iterate through each entered character
        if i in numeros:  
            # si el car�cter est� en la lista de n�meros permitidos / if the character is in allowed numbers
            x += 1  
    
        # otra forma: usando el c�digo ASCII con ord() / another way: using ASCII code with ord()
        # if (ord(i) >= 48 and ord(i) <= 57):

    if len(b) == x:   # si todos los caracteres son n�meros / if all characters are digits
         a.append(int(b))   # convierte a entero y agrega a la lista / convert to int and add to list
         n +=1              # incrementa el contador / increase counter
    else:
         print('El valor no es un numero')   # mensaje de error / error message
   
for i in a:  
    print(i)    # imprime cada n�mero de la lista / print each number from the list
    s+= i       # acumula la suma / accumulate the sum

print(f"La suma es {s}")   # imprime la suma total / print the total sum
