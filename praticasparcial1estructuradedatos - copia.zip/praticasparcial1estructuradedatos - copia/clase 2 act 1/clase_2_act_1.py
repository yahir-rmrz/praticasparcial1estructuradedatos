

# hacer un prgorama que lea 10 numeros y los almacene en un arreglo
# programa 3

a = [0,0,0,0,0,0,0,0,0,0]
for i in range(0,10):
    a[i] = int(input('Escribe un numero \n'))
    # La F antes del mensaje es para formatear el dato y agregar una variable para evitr concatenar 
    # \n salto de linea 
for i in a:
    print (i)
