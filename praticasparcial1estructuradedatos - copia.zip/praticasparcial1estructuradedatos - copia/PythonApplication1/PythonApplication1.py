

print ('hola mundo')
# + Suma
# - Resta
# * Multiplicacion 
# / division normal con decimales
# // division sin decimales
# # ** potencia o elevar a ej print(a**2 / print(a**1/2)) 
# mod
# and/or
# Operadores basicos < > <= >= != == not