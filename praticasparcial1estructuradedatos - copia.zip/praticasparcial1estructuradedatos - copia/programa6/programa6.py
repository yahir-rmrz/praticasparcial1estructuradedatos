# hacer un programa que lea nombre, edad y sexo de 5 personas, estos elementos
# tienen que estar dentro de una lista
#
# make a program that reads name, age and gender of 5 people, these elements
# must be stored inside a list


def inicio():
    while True:  
        # ciclo infinito hasta que se rompa con break / infinite loop until break is called
        c = 0  # contador (pero se reinicia en cada iteraci�n) / counter (but it resets every loop)
        
        n = input('Escribe tu nombre \n')  # pide nombre / ask for name
        e = input('Escribe tu edad \n')    # pide edad / ask for age
        s = input('Escribe tu sexo \n')    # pide sexo / ask for gender

        aux = "nombre: "+n, "edad: "+e, "Sexo: "+s  
        # crea una tupla con los datos / creates a tuple with the data

        per.append(aux)  # agrega la tupla a la lista principal / adds the tuple to the main list
        c+=1  # incrementa el contador / increases the counter

        if c >= 5:  # condici�n de salida (pero como c se reinicia nunca llega a 5) / exit condition (but since c resets, it never reaches 5)
            break

    print(per)  # muestra la lista de personas / prints the list of people
     
per = []  # lista vac�a donde se guardar�n las personas / empty list to store people

if __name__=='__main__':  
    inicio()  # llama a la funci�n principal / calls the main function



