﻿

a = 1   # coeficiente a de la ecuación cuadrática / coefficient a of the quadratic equation
b = 2   # coeficiente b de la ecuación cuadrática / coefficient b of the quadratic equation
c = -15 # coeficiente c de la ecuación cuadrática / coefficient c of the quadratic equation
p = 0   # variable auxiliar / auxiliary variable
m = 0   # variable auxiliar / auxiliary variable
r = 0   # discriminante / discriminant
ra = 0.0  # raíz cuadrada del discriminante / square root of the discriminant
d = 0.0   # denominador (2a) / denominator (2a)
x1 = 0.0  # primera solución / first solution
x2 = 0.0  # segunda solución / second solution

p = b**2       # calcula b² / calculates b²
m = 4 * a * c  # calcula 4ac / calculates 4ac
r = p - m      # discriminante (b² - 4ac) / discriminant (b² - 4ac)

if r > 0:  # si el discriminante es positivo / if discriminant is positive
    print('Si se puede')  # existen dos soluciones reales / two real solutions exist
    ra = r **(1/2)  # raíz cuadrada del discriminante / square root of discriminant
    d = 2 * a       # denominador = 2a / denominator = 2a
    x1 = (-b + ra)/d  # primera raíz / first root
    x2 = (-b - ra)/d  # segunda raíz / second root
    print(f'El  valor de x1 es: {x1:.2f}\nEl valor de x2 es: {x2:.2f}')
    # imprime las soluciones con 2 decimales / prints the solutions with 2 decimals
else:
    print('Error')  # no existen soluciones reales (discriminante ≤ 0) / no real solutions (discriminant ≤ 0)
