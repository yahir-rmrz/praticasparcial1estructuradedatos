a = int(input('Escribe un numero: '))  # Ask the user to enter a number | Solicita al usuario que ingrese un número
print(a**2)  # Calculate the power of the number (a²) | Calcula la potencia del número (a²)
print(a**(1/2))  # Calculate the square root of the number | Calcula la raíz cuadrada del número

# Operadores lógicos / Logical operators
'''
+, -, *   # Addition, subtraction, multiplication | Suma, resta, multiplicación
/ (exacta con desimales), //(sin desimales), ** (Potencia o elevar a), mod, and, or
/ division with decimals, // integer division, ** exponentiation, mod modulus, and/or logical operators
/ división exacta con decimales, // división entera, ** potencia, mod módulo, and/or operadores lógicos
'''

# Operadores diferenciales / Relational operators
'''
<, >, <>, >=, <=, !=, ==, not
< less than, > greater than, <> not equal, >= greater or equal, <= less or equal, != not equal, == equal, not negation
< menor que, > mayor que, <> diferente, >= mayor o igual, <= menor o igual, != distinto, == igual, not negación
'''
