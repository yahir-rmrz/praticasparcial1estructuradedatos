def validar(a):
    c = 0      # variable auxiliar entera / integer auxiliary variable
    d = 0.0    # variable auxiliar flotante / float auxiliary variable
    try:
        c = int(a)  # intenta convertir a entero / tries to convert to integer
        print('Es un valor numerico sin decimales. ')  
        # mensaje si la conversi�n a entero fue exitosa / message if conversion to integer was successful
    except ValueError:
        print("No es un valor numerico sin decimales. ")  
        # mensaje si la conversi�n a entero falla / message if conversion to integer fails

    try: 
        d = float(a)  # intenta convertir a flotante / tries to convert to float
        print('Es un valor numerico con decimales. ')  
        # mensaje si la conversi�n a float fue exitosa / message if conversion to float was successful
    except ValueError:
        print("No es un valor numerico con decimales. ")  
        # mensaje si la conversi�n a float falla / message if conversion to float fails



def leer():
    # ord obtiene el c�digo ASCII del car�cter / ord gets the ASCII code of a character
    # isalpha devuelve True si son solo letras / isalpha returns True if only letters
    # isdigit devuelve True si son solo n�meros / isdigit returns True if only numbers
    # try se usa para validar errores de conversi�n / try is used to handle conversion errors
    
    a = input('Escribe un dato o valor: \n')  # pide un dato al usuario / asks user for a value
    validar(a)  # llama a la funci�n para validarlo / calls the function to validate it



if __name__=='__main__':  
    leer()  # ejecuta la funci�n principal / runs the main function
