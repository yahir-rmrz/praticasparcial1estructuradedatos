# hacer un programa que lea 10 datos, si el dato es un numero almacenara en un arreglo,
# si es un caracter o caracteres se metera a una lista, cuando finalice el programa nos mostrara
# cuantos elementos nummericos y cuantos caracteres hay en una estructura.
#
# make a program that reads 10 inputs, if the input is a number it will be stored in an array,
# if it is a character or characters it will be stored in a list, when the program ends it will show us
# how many numeric elements and how many characters there are in each structure.


n = [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1]  
# arreglo con 11 posiciones inicializado en -1 / array with 11 positions initialized to -1

c = []   # lista vac�a para caracteres / empty list for characters
v = 0    # contador de entradas totales / counter for total inputs
v2 = 0   # contador de n�meros v�lidos (se usa despu�s) / counter for valid numbers (used later)

while(True):  # ciclo infinito controlado por "break" / infinite loop controlled by "break"
    d = input('Escribe un dato o numero \n')  
    # pide un dato por teclado / asks for input from keyboard
    v +=1   # incrementa el contador de entradas / increases input counter

    if d.isdigit():  
        n[v-1] = int(d)   # si es n�mero, lo guarda en el arreglo en la posici�n correspondiente / if it's a number, stores it in the array at the position
    elif d.isalpha():  
        c.append(d)   # si es letra(s), lo agrega a la lista / if it's alphabetic, adds it to the list

    if v > 10:   # cuando ya se han ingresado m�s de 10 datos / when more than 10 inputs have been entered
        break

print(f'el arreglo tiene {v2}')  # muestra la cantidad de n�meros (aunque v2 a�n no est� bien calculado) / shows the count of numbers (though v2 isn't updated yet)
print(f'La lista tiene {len(c)}')  # muestra cu�ntos caracteres se guardaron / shows how many characters were stored

for i in c:  
        if i != -1:   # aqu� revisa elementos pero en la lista de caracteres, no en el arreglo / checks elements, but it's iterating over characters list not the array
            v2 += 1   # incrementa el contador / increases the counter

print(c)  # imprime la lista de caracteres / prints the character list
print(n)  # imprime el arreglo de n�meros / prints the number array

