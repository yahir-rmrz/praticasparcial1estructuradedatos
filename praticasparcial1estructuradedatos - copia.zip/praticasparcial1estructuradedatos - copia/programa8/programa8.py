# hacer un programa que en una lista se introduzca cadenas de caracteres con las siguientes restricciones:
# 1- Las cadenas no deben tener espacios.
# 2- La cadena solo puede tener mayuscula la primer letra.
# 3- Obligatoriamente debe de tener todas las vocales.
# El programa no termina hasta que la lista tenga 5 elementos.
#
# make a program that stores strings in a list with the following restrictions:
# 1- The strings must not have spaces.
# 2- The string can only have the first letter uppercase.
# 3- It must contain all vowels.
# The program will not end until the list has 5 elements.


def inicio():
    a = "abcdefghijklmnopqrstuvwxyz"  
    # todas las letras min�sculas permitidas / all allowed lowercase letters
    co = 0   # contador (pero se usa de manera incorrecta para la condici�n final) / counter (but incorrectly used for final condition)
    l =[]    # lista donde se guardar�n las cadenas / list where the strings will be stored
   
    while(True):  # bucle infinito hasta cumplir condici�n / infinite loop until condition is met
        c = input('Escribe una cadena: \n')  
        # pide al usuario una cadena / asks user for a string

        for i in c[1:]:  
            # revisa cada car�cter a partir del segundo / checks each character from the second onward
            if i in a:  
                co +=1          # si es min�scula, incrementa contador / if lowercase, increase counter
                l.append(c)     # agrega la cadena a la lista (pero sin revisar todas las restricciones) / adds string to the list (but doesn't check all restrictions)
            else:
                print('no hay minusculas')  # mensaje si hay error / message if invalid char
        
        if co <= 5:   # condici�n de parada (pero mal implementada, se rompe antes de 5 cadenas) / stop condition (but incorrectly implemented, breaks before reaching 5)
            print(l)
            break


if __name__=='__main__':  
    inicio()  # ejecuta la funci�n principal / runs the main function
