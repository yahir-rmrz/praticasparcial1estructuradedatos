# hacer un programa que lea una cadena y que muestre en pantalla cuantos numeros tiene,
# cuantas mayusculas, cuantas minusculas y cuantos espacios
#
# make a program that reads a string and shows how many numbers it has,
# how many uppercase letters, lowercase letters, and spaces


def inicio():
   
  numeros = "0123456789"  
  # cadena con todos los d�gitos posibles / string with all possible digits
  
  cn = 0    # contador de n�meros / counter for numbers
  cmay = 0  # contador de may�sculas / counter for uppercase letters
  cmin = 0  # contador de min�sculas / counter for lowercase letters
  ce = 0    # contador de espacios / counter for spaces

  cadena = input('Escribe una cadena: \n')  
  # pide al usuario una cadena de texto / asks the user for a string

  for i in cadena:  
      # recorre cada car�cter de la cadena / iterates through each character in the string
      if i in numeros:  
          cn += 1   # si es n�mero, aumenta contador / if it's a number, increase counter
      if i == ' ':  
          ce += 1   # si es espacio, aumenta contador / if it's a space, increase counter
      if ord(i)>=97 and ord(i)<=122:  
          cmin +=1  # si es min�scula (c�digo ASCII entre 97 y 122) / if lowercase (ASCII code between 97 and 122)
      if ord(i)>=65 and ord(i)<=90:  
             cmay += 1  # si es may�scula (c�digo ASCII entre 65 y 90) / if uppercase (ASCII code between 65 and 90)

  # muestra resultados / show results
  print(f'Los espacios son: {ce}\n Los numeros: {cn}\n Las mayusculas: {cmay}\n Y las minusculas: {cmin}')

if __name__=='__main__':  
       inicio()  # ejecuta la funci�n principal / executes the main function
