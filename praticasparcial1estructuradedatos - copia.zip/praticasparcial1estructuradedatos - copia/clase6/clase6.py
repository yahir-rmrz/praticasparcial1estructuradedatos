
def hola(): #definicion de m etodo o funcion 
    
 while(True):
    d = input('Escribe un dato o numero \n')
    v +=1

    if d.isdigit():
        n[v-1] = int(d)
    elif d.isalpha():
       c.append(d) 
    if v >10:
        break


if __name__=='__main__':# metodo principal
    hola()
