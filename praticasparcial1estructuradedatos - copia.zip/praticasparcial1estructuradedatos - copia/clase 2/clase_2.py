
a = [10] # arreglo / array
b =[] # lista / list

a[0] = 10  # asignamos valor 10 al primer elemento / assign value 10 to the first element
a[1] = 10  # intentamos asignar valor en una posici�n inexistente / trying to assign value in a non-existent position

b={'hola', 10, 10, 5, False,  'm', {1, 2, 3, 4}}  
# conjunto (set) con valores repetidos y un set anidado / set with repeated values and a nested set

# ciclos y condiciones / loops and conditions 
if (len(a) > len(b)):  
    print ('A es mayor')   # se imprime si la lista "a" es m�s grande / prints if list "a" is larger
else:
    print('B es mayor')    # se imprime si "b" es m�s grande o igual / prints if "b" is larger or equal

# ciclos / loops
# for 
for i in a:  
    print(a)  # imprime toda la lista en cada iteraci�n / prints the whole list on each iteration

# foreach (Python usa "for" para recorrer colecciones) / foreach (Python uses "for" to iterate collections)


