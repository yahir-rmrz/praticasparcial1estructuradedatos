# instrucciones de entrada y salida
# input and output instructions

# print() o print(f)
# print() or print(f)

#prnt('hola mundo')  # ejemplo con error de sintaxis / example with syntax error
#print(f'hols mundo numeros {10}')  # impresi�n con formato / formatted print

# entrada datos / data input
#input('escribe un numero') # se introducen solo letras / only letters are typed

# casting para convertir a valores especificos / casting to convert to specific values
#f = float(input('escribe un numero con decimales'))
#a = 0
#a = int(input('escribe un numero'))
#c= 120


# hacer un programa que lea un nombre y precio de un producto, el programa calculara el costo y precio de venta.
# El costo involucra el 12% y el IVA el 16%.
#
# make a program that reads the name and price of a product, the program will calculate the cost and selling price.
# The cost involves 12% and VAT 16%.


# for i in range(1,5) rango de valor inicial hasta el numero final del rango elegido sin incluirlo
# for i in range(1,5) range from initial value to final number without including it

while(True):  # ciclo infinito / infinite loop
 n = input('Escribe el nombre del producto: \n')  # pide el nombre del producto / ask for product name
 p = 0.0  
 p = float(input('Escribe e [recio del producto: \n'))  
 # pide el precio y lo convierte a float / ask for the price and convert to float

 costo = p * 1.12  
 # costo incrementado en 12% / cost increased by 12%

 IVA = costo * 1.16  
 # costo con 16% adicional de IVA / cost with additional 16% VAT

 (print(f'Producto: {n} \nCosto de venta: {costo:.2f} \nEl precio total es: {IVA:.2f}'))  
 # imprime el producto, costo y precio total con 2 decimales / print product, cost and total price with 2 decimals
 
 res = input('Deseas consultar otro producto? Y/N: \n')  
 # pregunta si se desea continuar / ask if user wants to continue

 if(res =='n' or res=='N'):  
    break  # si la respuesta es N/n, termina el ciclo / if answer is N/n, loop ends
