# hacer un programa que lea un dato y que lo almacene en una lista respetando su tipo de dato
# make a program that reads a value and stores it in a list while keeping its data type


def validar(c):
    d = 0.0  # variable auxiliar flotante / float auxiliary variable
    e = 0    # variable auxiliar entera / integer auxiliary variable
    try:
        e = int(c)      # intenta convertir a entero / tries to convert to integer
        return e        # si es entero, lo regresa / if it's integer, return it
    except ValueError:
        print('No es un entero')  # si falla la conversi�n a entero / if integer conversion fails
       
    try:
        d = float(c)    # intenta convertir a flotante / tries to convert to float
        return d        # si es flotante, lo regresa / if it's float, return it
    except ValueError:
        print('No es un decimal')  # si falla la conversi�n a flotante / if float conversion fails
    
    return c  # si no es n�mero, regresa el valor como cadena / if not a number, return as string


def leer():
    c = input('escribe un dato: \n')  # pide un dato al usuario / asks user for a value
    dato = validar(c)                 # valida el tipo de dato / validates the data type
    lista.append(dato)                 # lo agrega a la lista respetando su tipo / adds it to the list keeping its type


lista = []  # lista donde se almacenar�n los datos / list where the values will be stored

if __name__=='__main__':  
    while(True):  # ciclo infinito hasta que el usuario diga "n" / infinite loop until user types "n"
       leer()
       res = input('Deseas otro? s/n')  # pregunta si se desea ingresar m�s / ask if user wants to enter more
       if res =='n' or res == 'N':  
         print(lista)  # muestra la lista con los datos ingresados / print the list with entered values
         break
