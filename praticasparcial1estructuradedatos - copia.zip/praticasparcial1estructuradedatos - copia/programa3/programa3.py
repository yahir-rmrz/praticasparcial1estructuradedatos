# hacer un programa que lea 10 numeros y los almacene en un arreglo
# programa 3
# make a program that reads 10 numbers and stores them in an array
# program 3

a = [0,0,0,0,0,0,0,0,0,0]  # arreglo inicializado con 10 ceros / array initialized with 10 zeros

for i in range(0,10):  
    a[i] = int(input('Escribe un numero \n'))  
    # se pide un n�mero y se guarda en la posici�n i / ask for a number and store it in position i
    # La F antes del mensaje es para formatear el dato y agregar una variable para evitar concatenar 
    # The F before the message is used to format the string and add a variable instead of concatenating
    # \n salto de linea / \n newline

for i in a:  
    print (i)  
    # imprime cada n�mero almacenado en el arreglo / prints each number stored in the array
